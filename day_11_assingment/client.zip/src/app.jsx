import axios from "axios";
import { useEffect, useState } from "react";
import CreateUserComponent from "./component/createUser";
import EditUserComponent from "./component/editUser";
import ListUserComponent from "./component/listUser";

let App = ()=> {
    let [users, setUsers] = useState([]);
    let [show, toggleShow] = useState(true);
    let [euser, setEditUser] = useState({ title : "", firstname : "", lastname : "", power : "", city : "" });

    useEffect(()=>{
        refresh();
    });

    let refresh = ()=>{
        axios.get("http://localhost:5050/data")
        .then(res => setUsers(res.data))
        .catch(error => console.log("Error ", error ));
    }
    
    return <div className="container">
            <h1>Users MongoDB App</h1>
                {/* <p>{ JSON.stringify(users) }</p> */}
                { show && <div><CreateUserComponent {...{users, setUsers, toggleShow}}/></div>}
                { !show && <div><EditUserComponent {...{ euser, setEditUser, toggleShow}}/></div>}
                <div><ListUserComponent {...{users, setUsers, setEditUser, toggleShow}}/></div>
                </div>
}

export default App;