import axios from "axios";
import { useEffect } from "react";

let ListUserComponent = (props)=> {

  useEffect(()=>{
    refresh();
  });

  let refresh = ()=>{
      axios.get("http://localhost:5050/data")
      .then(res => props.setUsers(res.data))
      .catch(error => console.log("Error ", error ));
  }


let editUserHandler = (uid)=>{
  // alert("are you sure to edit this user's info "+ uid );
  axios.get("http://localhost:5050/update/"+uid)
  .then(res => {
      props.setEditUser(res.data)
      props.toggleShow(false)
  })
  .catch(err => console.log(err.error))
}

let deleteHandler = (uid)=>{
  axios.delete("http://localhost:5050/delete/"+uid)
  .then( res => { 
    console.log( res.data.message );
    refresh();
  })
  .catch(err => {
    console.log(err)
  })
}

return <div>
        <hr />
          <div>
          { props.users.length > 0 && <div>
              <h1>Users List</h1>
              <table className="table">
                  <thead>
                      <tr>
                          <th>Title</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>City</th>
                          <th>Power</th>
                          <th>Edit</th>
                          <th>Delete</th>
                      </tr>
                  </thead>
                  <tbody>
                      {
                          props.users.map( (hero, idx) => {
                              return <tr key={ idx }>
                                          <td>{ hero.title }</td>
                                          <td>{ hero.firstname }</td>
                                          <td>{ hero.lastname }</td>
                                          <td>{ hero.city }</td>
                                          <td>{ hero.power }</td>
                                          <td>
                                              <button onClick={ ()=> editUserHandler(hero._id) } className="btn btn-warning">Edit</button>
                                          </td>
                                          <td>
                                              <button onClick={ ()=> deleteHandler(hero._id)} className="btn btn-danger">Delete</button>
                                          </td>
                                      </tr>
                          })
                      }
                  </tbody>
              </table>
          </div>
}
      </div>
      </div>
}
export default ListUserComponent;
