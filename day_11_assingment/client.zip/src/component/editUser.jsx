import axios from "axios";
import { useEffect } from "react";

let EditUserComponent = (props)=> {
  
    useEffect(()=>{
      refresh();
  });

  let euser = props.euser;

  let refresh = ()=>{
      axios.get("http://localhost:5050/data")
      .then(res => props.setUsers(res.data))
      .catch(error => console.log("Error ", error ));
  }
    
  let storeEditInfoHandler = (evt)=>{
      props.setEditUser({...euser, [evt.target.id] : evt.target.value });
  };

  let updateSelectedUserInfo = (uid)=> {
    axios.post("http://localhost:5050/update/"+uid, euser)
    .then(res => {
        console.log(res.data.message);
        refresh();
        props.toggleShow(true)
    })
    .catch(err => console.log(err))
  }

  return<div>
    <hr />
        <div> 
        <h1>Edit The Selected User</h1>
        <div className="mb-3">
            <label htmlFor="title" className="form-label">Edit User Title</label>
            <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.title} className="form-control" id="title"/>
        </div>
        <div className="mb-3">
            <label htmlFor="firstname" className="form-label">Edit User First Name</label>
            <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.firstname} className="form-control" id="firstname"/>
        </div>
        <div className="mb-3">
            <label htmlFor="lastname" className="form-label">Edit User Last Name</label>
            <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.lastname} className="form-control" id="lastname"/>
        </div>
        <div className="mb-3">
            <label htmlFor="city" className="form-label">Edit User City</label>
            <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.city} className="form-control" id="city"/>
        </div>
        <div className="mb-3">
            <label htmlFor="power" className="form-label">Edit User Power</label>
            <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.power} type="range" min={0} max={10} step={1} className="form-control" id="power"/>
        </div>
        <button type="submit" onClick={ ()=> updateSelectedUserInfo(euser._id) } className="btn btn-primary">Edit User Info </button>
        </div>
    </div>
}

export default EditUserComponent;